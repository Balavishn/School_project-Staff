package com.example.staff_navigations.ui.help;

import androidx.lifecycle.ViewModel;

public class HelpViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}