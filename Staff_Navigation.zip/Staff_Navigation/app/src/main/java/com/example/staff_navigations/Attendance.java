package com.example.staff_navigations;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.staff_navigation.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class Attendance extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{
    RecyclerView present;
    DatabaseReference studentref,staffref;
    String class_sec,sub;
    List<String> student_name,present_listt;
    Button ok;

    Workbook wb=new HSSFWorkbook();
    Cell cell=null,cell1=null;

    StorageReference refst;
    TextView date;
    DatePickerDialog datePickerDialog;
    final Calendar myCalendar = Calendar.getInstance ();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        present=findViewById(R.id.attendance_rec);
        present.setLayoutManager(new LinearLayoutManager(this));
        student_name=new ArrayList<>();
        present_listt=new ArrayList<>();
        ok=findViewById(R.id.ok_attendance);
        date=findViewById(R.id.select_date_attendance);
        class_sec=getIntent().getStringExtra("class");
        sub=getIntent().getStringExtra("subject");
        refst= FirebaseStorage.getInstance().getReference("Academic").child("Attendance");
        String classs=class_sec.substring(0,class_sec.indexOf("-"));
        staffref=FirebaseDatabase.getInstance().getReference("Staff_Details").child("Academic").child(classs).child("Attendance").child(class_sec);
        studentref= FirebaseDatabase.getInstance().getReference("STUDENT DETAILS");
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog=new DatePickerDialog(Attendance.this,
                        Attendance.this,
                        myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
                /*final DatePickerDialog.OnDateSetListener datetime = new DatePickerDialog.OnDateSetListener () {

                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        myCalendar.set ( Calendar.YEAR, year );
                        myCalendar.set ( Calendar.MONTH, monthOfYear );
                        myCalendar.set ( Calendar.DAY_OF_MONTH, dayOfMonth );
                    }

                };*/

               /* d1.setOnClickListener ( new View.OnClickListener () {

                    @Override
                    public void onClick(View v) {

                        new DatePickerDialog ( Attendance.this, datetime, myCalendar.get ( Calendar.YEAR ), myCalendar.get ( Calendar.MONTH ), myCalendar.get ( Calendar.DAY_OF_MONTH ) ).show ();

                    }
                } );*/
            }
        });
        studentref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot s:snapshot.getChildren()){
                    student_name.add(s.child("Student_Name").getValue().toString());
                    present_listt.add("absent");
                    Log.d("student_name",s.child("Student_Name").getValue().toString());
                }
                attend_adapter a=new attend_adapter(student_name,Attendance.this);
                present.setAdapter(a);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i=0;i<student_name.size();i++){
                    staffref.child(student_name.get(i)).child(date.getText().toString()).child(student_name.get(i)).setValue(present_listt.get(i));
                    Log.d("Last_present",student_name.get(i)+" "+present_listt.get(i));
                }
                export();
            }
        });
    }

    public void presentt(String name,int pos,String present){
        present_listt.set(pos,present);
        Log.d("present_student",name+" "+present);
    }
    public void export(){
        String filename="attendance";
        CellStyle cellStyle = wb.createCellStyle();
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_BLUE.index);
        Sheet sheet = wb.createSheet("Details");
        for(int i=1;i<=student_name.size();i++){
            Row row = sheet.createRow(i);
            cell=row.createCell(0);
            cell1=row.createCell(1);
            cell.setCellValue(student_name.get(i-1));
            cell1.setCellValue(present_listt.get(i-1));
            cell.setCellStyle(cellStyle);
            cell1.setCellStyle(cellStyle);
        }

        File file = new File(getExternalFilesDir(null),filename + ".xls");
        Log.d("filestore", file.getAbsolutePath().toString());
        if (!file.isDirectory()) {
            Log.d("not exist", "notexits");
        }
        if (true) {
            Log.d("crete exist", "creat exits");
        }
        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(file);
            wb.write(outputStream);
            InputStream inputStream=new FileInputStream(file);
            Toast.makeText(getApplicationContext(), "File Stored in" + file.getAbsolutePath().toString(), Toast.LENGTH_LONG).show();
            refst.child(date.getText().toString()).child("attendance.xls").putStream(inputStream).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(getApplicationContext(),"file Upload",Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getApplicationContext(),"file not Upload",Toast.LENGTH_SHORT).show();
                }
            });
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
        myCalendar.set ( Calendar.YEAR, year );
        myCalendar.set ( Calendar.MONTH, monthOfYear );
        myCalendar.set ( Calendar.DAY_OF_MONTH, dayOfMonth );
        String myFormat = "dd-MM-yyyy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat( myFormat, Locale.US );

        date.setText ( sdf.format ( myCalendar.getTime () ) );
    }
}