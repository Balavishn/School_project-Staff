package com.example.staff_navigations;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.staff_navigation.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class attend_adapter extends RecyclerView.Adapter<attend_adapter.myattend> {
    List<String> student_name;
    Attendance attendance;

    public attend_adapter(List<String> student_name, Context c) {
        this.student_name = student_name;
        this.attendance=(Attendance)c;
    }

    @NonNull
    @Override
    public myattend onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.single_attendance,parent,false);
        myattend viewHold=new myattend(v);
        return viewHold;
    }

    @Override
    public void onBindViewHolder(@NonNull myattend holder, int position) {
        holder.name.setText(student_name.get(position));
    }

    @Override
    public int getItemCount() {
        return student_name.size();
    }

    public class myattend extends RecyclerView.ViewHolder{
        TextView name;
        Switch present;
        public myattend(@NonNull final View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.student_name);
            present=itemView.findViewById(R.id.switch1);
            present.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    String present;
                    if(b){
                       present="present";
                    }
                    else{
                        present="absent";
                    }
                    attendance.presentt(name.getText().toString(),student_name.indexOf(name.getText().toString()),present);
                    Toast.makeText(itemView.getContext(),String.valueOf(b),Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
