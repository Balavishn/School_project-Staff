package com.example.staff_navigations;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;


import com.example.staff_navigation.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import org.apache.poi.hssf.record.formula.functions.T;

import java.util.HashMap;

public class SignUpStaffSide extends AppCompatActivity {

    EditText name,phnenum,pass,pass1,id,email,count;
    Button register;

    //String for Class
    String num;
    //String for Count
    String c;
    RecyclerView r;

    CircleImageView profile;



    //String[] subject1 = getResources().getStringArray(R.array.Subject2);
    private  final static String INTENTVALUE="1" ;

    String s;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference,clsref;
    StorageReference profileref;
    signupadapter signupadapter;

    String[] clsssdata,sectdata,subdata;

    String tcls_sec="",tsubb="";
    final String[] Sname = new String[1];
    StorageTask mUploadTask;
    Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_staff_side);
        name=findViewById(R.id.staffname);
        id=findViewById(R.id.staffid);

        phnenum=findViewById(R.id.staffnumber);
        pass=findViewById(R.id.staffpass);
        pass1=findViewById(R.id.staffpass1);
        email=findViewById(R.id.staffemail);
        register=findViewById(R.id.register);
        count=findViewById(R.id.Count);
        profile=findViewById(R.id.imageView2);

        r=findViewById(R.id.recycle_signup);
        r.setLayoutManager(new LinearLayoutManager(this));

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i= new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(i,100);*/
               choose();
            }
        });


        count.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!count.getText().toString().equals("")) {
                    c = count.getText().toString();
                    signupadapter = new signupadapter(SignUpStaffSide.this, Integer.parseInt(c));
                    r.setAdapter(signupadapter);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        reference=FirebaseDatabase.getInstance().getReference("Staff_Details");
        clsref=FirebaseDatabase.getInstance().getReference("Staff_Details");
        profileref=FirebaseStorage.getInstance().getReference("Staff_Details").child("Profile");

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String Sid, Sphnenum, Spass, Spass1, Semail;
                Sname[0] = name.getText().toString();
                Sid = id.getText().toString();
                Semail = email.getText().toString();

                Sphnenum = phnenum.getText().toString();
                Spass = pass.getText().toString();
                Spass1 = pass1.getText().toString();

                if (!TextUtils.isEmpty(Sname[0])
                        && !TextUtils.isEmpty(Sid)
                        && !TextUtils.isEmpty(Sphnenum)
                        && !TextUtils.isEmpty(Sphnenum)
                        && !TextUtils.isEmpty(Spass)
                        && !TextUtils.isEmpty(Spass1)
                        && !TextUtils.isEmpty(Semail)

                ) {
                    if(!count.getText().toString().equals("")) {

                        if (Spass.length() >= 8 && Spass1.length() >= 8) {
                            if (Spass.equals(Spass1)) {


                                if (Sphnenum.length() == 10) {
                                    final HashMap<String, String> map = new HashMap<>();
                                    map.put("Staff_Name", Sname[0]);
                                    map.put("Staff_Id", Sid);


                                    map.put("Staff_Number", Sphnenum);
                                    map.put("Staff_Email", Semail);
                                    map.put("Staff_Password", Spass);

                                    mUploadTask = profileref.child(Sname[0]).child("profile.jpg").putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            Task<Uri> urim=taskSnapshot.getStorage().getDownloadUrl();

                                              while (!urim.isComplete()) ;
                                              Uri url = urim.getResult();
                                             map.put("profile_img", url.toString());
                                            reference.child(Sname[0]).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {
                                                        getdata();
                                                        Intent intent = new Intent(getApplicationContext(), LoginStaffSide.class);
                                                        Toast.makeText(SignUpStaffSide.this, "Uploaded Sucessfully...", Toast.LENGTH_SHORT).show();
                                                        finish();

                                                        SharedPreferences preferences = getSharedPreferences("NUMBER", MODE_PRIVATE);
                                                        SharedPreferences.Editor editor = preferences.edit();
                                                        editor.putString("Register", Sname[0]);
                                                        editor.putString("Password", Spass);
                                                        editor.putString("StaffID", Sid);

                                                        editor.commit();

                                                        startActivity(intent);
                                                        finish();
                                                    } else
                                                        Toast.makeText(SignUpStaffSide.this, "Error", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        }
                                    });

                                } else
                                    Toast.makeText(SignUpStaffSide.this, "Maximum 10-Digit Numbers", Toast.LENGTH_SHORT).show();
                            } else
                                Toast.makeText(SignUpStaffSide.this, "Fields Mismatching", Toast.LENGTH_SHORT).show();
                        } else
                            Toast.makeText(SignUpStaffSide.this, "Must Have 8 Characters", Toast.LENGTH_SHORT).show();
                    } else
                        Toast.makeText(SignUpStaffSide.this, "Handling Class Missing", Toast.LENGTH_SHORT).show();

                } else
                    Toast.makeText(SignUpStaffSide.this, "Constraints Missing", Toast.LENGTH_SHORT).show();
            }
        });



    }

   /* protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //bar.setVisibility(View.VISIBLE);
        uri=data.getData();
        profile.setImageURI(uri);
    }*/

    public void getdata(){
        clsssdata=signupadapter.getclassdata();
        sectdata=signupadapter.getSecdata();
        subdata=signupadapter.getSubjdata();
        final HashMap<String, String> classmap = new HashMap<>();
        for(int i=0;i<clsssdata.length;i++){
            tcls_sec+=clsssdata[i]+"-"+sectdata[i];
            tsubb+=subdata[i];
            if(!(i==clsssdata.length-1)){
                tcls_sec+=",";
                tsubb+=",";
            }
            Log.d("datataclass",clsssdata[i]+sectdata[i]+subdata[i]);
        }
        classmap.put("class",tcls_sec);
        classmap.put("subject",tsubb);
        Log.d("class",tcls_sec+" "+tsubb);


        clsref.child(Sname[0]).child("class").setValue(classmap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void choose(){
        CropImage.activity().start(SignUpStaffSide.this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result=CropImage.getActivityResult(data);
            if(resultCode==RESULT_OK){
                uri=result.getUri();
                profile.setImageURI(uri);
            }
            else if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Toast.makeText(getApplicationContext(),result.getError().getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}



















