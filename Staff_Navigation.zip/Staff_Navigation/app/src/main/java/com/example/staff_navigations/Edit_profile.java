package com.example.staff_navigations;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import com.example.staff_navigation.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Edit_profile extends AppCompatActivity {
    EditText name,phnenum,pass,id,email;
    Button ok;
    Spinner classs,sub,section;
    DatabaseReference reference;
    String semail;
    String names,phnenums,passs,ids,emails,subs;
    EditText class_count;
    Button add_class;
    String[] class_list={"1","2","3","4","5","6","7","8","9","10"};
    String[] section_list={"A","B","C"};
    String[] subject_list={"Tamil","English","Maths","Science","Social Science"};
    String count;
    RecyclerView er;
    DatabaseReference ref,clsref;

    signupadapter signupadapter;

    ArrayAdapter<String> class_arrayAdapter;
    ArrayAdapter<String> sec_arrayAdapter;
    ArrayAdapter<String> sub_arrayAdapter;
    List<String> values_get=new ArrayList<>();
    String user;

    String[] clsssdata,sectdata,subdata;

    String tcls_sec="",tsubb="";
    CircleImageView profile;
    Uri uri;
    StorageReference profileref;
    StorageTask mUploadTask;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        name=findViewById(R.id.edit_username);
        id=findViewById(R.id.edit_staff_id);
        phnenum=findViewById(R.id.edit_contact_no);
        pass=findViewById(R.id.edit_password);
        email=findViewById(R.id.edit_email);
        ok=findViewById(R.id.edit_button);
        class_count=findViewById(R.id.edit_class_id);
        profile=findViewById(R.id.imageView3);
        profileref= FirebaseStorage.getInstance().getReference("Staff_Details").child("Profile");

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent i= new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(i,100);*/
               choose();
            }
        });

        final SharedPreferences preferences =getSharedPreferences("NUMBER",MODE_PRIVATE);
        final String[] s = {preferences.getString("Register", "default")};
        reference= FirebaseDatabase.getInstance().getReference("Staff_Details");
        er=findViewById(R.id.edit_recycle);
        er.setLayoutManager(new LinearLayoutManager(this));
        //Database
        user=preferences.getString("Register","default");
        ref= FirebaseDatabase.getInstance().getReference("Staff_Details");
        clsref=FirebaseDatabase.getInstance().getReference("Staff_Details");
        class_count.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!class_count.getText().toString().equals("")) {
                    count = class_count.getText().toString();
                    signupadapter = new signupadapter(Edit_profile.this, Integer.parseInt(count));
                    er.setAdapter(signupadapter);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        class_arrayAdapter=new ArrayAdapter<>(this,R.layout.spinner_dropdown_textview,class_list);
        // class_arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sec_arrayAdapter=new ArrayAdapter<>(this,R.layout.spinner_dropdown_textview,section_list);
        //   sec_arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sub_arrayAdapter=new ArrayAdapter<>(this,R.layout.spinner_dropdown_textview,subject_list);
        //    sub_arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
       // semail=MainActivity.getemail();


        reference.child(s[0]).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                    name.setText(snapshot.child("Staff_Name").getValue().toString());
                    phnenum.setText(snapshot.child("Staff_Number").getValue().toString());
                    pass.setText(snapshot.child("Staff_Password").getValue().toString());
                    id.setText(snapshot.child("Staff_Id").getValue().toString());
                    email.setText(snapshot.child("Staff_Email").getValue().toString());
                    Picasso.get().load(snapshot.child("profile_img").getValue().toString()).into(profile);
                    uri=Uri.parse(snapshot.child("profile_img").getValue().toString());
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s[0] =preferences.getString("Register","default");
                names=name.getText().toString();
                phnenums=phnenum.getText().toString();
                passs=pass.getText().toString();
                ids=id.getText().toString();
                emails=email.getText().toString();
             //   subs=sub.getSelectedItem().toString();
                if (!TextUtils.isEmpty(names)
                        && !TextUtils.isEmpty(ids)
                        && !TextUtils.isEmpty(phnenums)
                        && !TextUtils.isEmpty(passs)
                        && !TextUtils.isEmpty(emails)) {
                    if (!class_count.getText().toString().equals("")) {

                            if (passs.length() >= 8) {
                                final HashMap<String, String> map = new HashMap<>();
                                map.put("Staff_Name", names);
                                map.put("Staff_Id", ids);
                                // map.put("Staff_Sub", subs);
                                map.put("Staff_Number", phnenums);
                                map.put("Staff_Email", emails);
                                map.put("Staff_Password", passs);
                                mUploadTask = profileref.child(names).child("profile.jpg").putFile(uri);
                                        profileref.child(names).child("profile.jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                            @Override
                                            public void onSuccess(Uri uri) {
                                                map.put("profile_img", uri.toString());
                                                reference.child(names).setValue(map);
                                                ref = FirebaseDatabase.getInstance().getReference("Staff_Details").child(names);
                                                getdata();
                                                if (!names.equals(s[0])) {
                                                    reference.child(s[0]).removeValue();
                                                    profileref.child(s[0]).delete();
                                                }
                                                SharedPreferences preferences = getSharedPreferences("NUMBER", MODE_PRIVATE);
                                                SharedPreferences.Editor editor = preferences.edit();
                                                editor.putString("Register", names);
                                                editor.putString("Password", passs);
                                                editor.commit();

                                              //  Toast.makeText(getApplicationContext(), "Edit Sucess", Toast.LENGTH_SHORT).show();
                                            }


                                        });

                            } else
                                Toast.makeText(getApplicationContext(), "Enter Valid 10 digit Number", Toast.LENGTH_SHORT).show();

                    }else Toast.makeText(getApplicationContext(), "Enter Class Count", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(getApplicationContext(), "Enter All fields", Toast.LENGTH_SHORT).show();
             //   Intent intent = new Intent(getApplicationContext(), My_Account__Fragment.class);
             //   startActivity(intent);
            }
        });

    }

 /*   protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //bar.setVisibility(View.VISIBLE);
        uri=data.getData();
        profile.setImageURI(uri);
    }*/

    public void getdata(){
        clsssdata=signupadapter.getclassdata();
        sectdata=signupadapter.getSecdata();
        subdata=signupadapter.getSubjdata();
        final HashMap<String, String> classmap = new HashMap<>();
        for(int i=0;i<clsssdata.length;i++){
            tcls_sec+=clsssdata[i]+"-"+sectdata[i];
            tsubb+=subdata[i];
            if(!(i==clsssdata.length-1)){
                tcls_sec+=",";
                tsubb+=",";
            }
            Log.d("datataclass",clsssdata[i]+sectdata[i]+subdata[i]);
        }
        classmap.put("class",tcls_sec);
        classmap.put("subject",tsubb);
        Log.d("class",tcls_sec+" "+tsubb);


        clsref.child(names).child("class").setValue(classmap).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void choose(){
        CropImage.activity().start(Edit_profile.this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result=CropImage.getActivityResult(data);
            if(resultCode==RESULT_OK){
                uri=result.getUri();
                profile.setImageURI(uri);
            }
            else if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Toast.makeText(getApplicationContext(),result.getError().getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}