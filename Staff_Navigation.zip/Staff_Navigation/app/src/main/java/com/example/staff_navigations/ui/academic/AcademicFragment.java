package com.example.staff_navigations.ui.academic;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.example.staff_navigation.R;
import com.example.staff_navigations.*;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.content.Context.MODE_PRIVATE;

public class AcademicFragment extends Fragment {
    Spinner subject,class_sec;
    String[] class_list,sub_list;
    DatabaseReference sub_reference,class_ref;
    SharedPreferences preferences;
    String s,cls,sub;
    ArrayAdapter<String> class_arrayAdapter;
    ArrayAdapter<String> sub_arrayAdapter;
    CardView syll,time_table,study_content,homework,attendance,mark,performance;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        final View root = inflater.inflate(R.layout.fragment_academic, container, false);
        subject=root.findViewById(R.id.academic_subject);
        class_sec=root.findViewById(R.id.academic_class_sec);
        syll=root.findViewById(R.id.syllabus);
        homework=root.findViewById(R.id.homework);
        time_table=root.findViewById(R.id.timetable);
        study_content=root.findViewById(R.id.study_content);
        attendance=root.findViewById(R.id.attendance_view);
        mark=root.findViewById(R.id.Mark_view);
        performance=root.findViewById(R.id.performance_view);
        preferences =getContext().getSharedPreferences("NUMBER",MODE_PRIVATE);
        s=preferences.getString("Register","default");
        class_ref= FirebaseDatabase.getInstance().getReference("Staff_Details").child(s).child("class");

     //   Log.d("classssssss",reference.toString());

        class_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                   cls=snapshot.child("class").getValue().toString();
                   sub=snapshot.child("subject").getValue().toString();
                    class_list=cls.split(",");
                    sub_list=sub.split(",");
                    Log.d("ccc",class_list.toString()+sub_list.toString());
                    class_arrayAdapter=new ArrayAdapter<>(root.getContext(),android.R.layout.simple_list_item_1,class_list);
                    sub_arrayAdapter=new ArrayAdapter<>(root.getContext(),android.R.layout.simple_list_item_1,sub_list);
                    class_sec.setAdapter(class_arrayAdapter);
                    subject.setAdapter(sub_arrayAdapter);
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        Log.d("classss",cls+sub);

        syll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(), academic_syllabus.class);
                i.putExtra("class",class_sec.getSelectedItem().toString());
                i.putExtra("subject",subject.getSelectedItem().toString());
                startActivity(i);
            }
        });

        attendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(), Attendance.class);
                i.putExtra("class",class_sec.getSelectedItem().toString());
                i.putExtra("subject",subject.getSelectedItem().toString());
                startActivity(i);
            }
        });

        mark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(), Mark_student.class);
                i.putExtra("class",class_sec.getSelectedItem().toString());
                i.putExtra("subject",subject.getSelectedItem().toString());
                startActivity(i);
            }
        });

        performance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(), Perforamce_tab.class);
                i.putExtra("class",class_sec.getSelectedItem().toString());
                i.putExtra("subject",subject.getSelectedItem().toString());
                startActivity(i);
            }
        });

        time_table.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(), academic_timetable.class);
                i.putExtra("class",class_sec.getSelectedItem().toString());
                i.putExtra("subject",subject.getSelectedItem().toString());
                startActivity(i);
            }
        });

        study_content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(), academic_study_content.class);
                i.putExtra("class",class_sec.getSelectedItem().toString());
                i.putExtra("subject",subject.getSelectedItem().toString());
                startActivity(i);
            }
        });

        homework.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(), academic_homework.class);
                i.putExtra("class",class_sec.getSelectedItem().toString());
                i.putExtra("subject",subject.getSelectedItem().toString());
                startActivity(i);
            }
        });

     //  class_list=cls.split(",");
     //   sub_list=sub.split(",");

        return root;
    }

}