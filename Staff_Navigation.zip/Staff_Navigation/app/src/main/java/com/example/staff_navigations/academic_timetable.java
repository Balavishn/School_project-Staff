package com.example.staff_navigations;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.staff_navigation.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import static android.os.Environment.DIRECTORY_DOWNLOADS;

public class academic_timetable extends AppCompatActivity {

    Button create,upload,view;
    ProgressBar progressBar;

    StorageReference mStorageReference;
    DatabaseReference mDatabaseReference;

    String class_sec,sub;
    final String[] geturl = {""};
    StorageTask mUploadTask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academic_timetable);
        create=findViewById(R.id.create_time);
        upload=findViewById(R.id.Upload_timetable);
        view=findViewById(R.id.View_timetable);
        progressBar=findViewById(R.id.progressBar_time);

        progressBar.setVisibility(View.GONE);

        SharedPreferences preferences =getSharedPreferences("NUMBER",MODE_PRIVATE);
        String s=preferences.getString("Register","default");
        class_sec=getIntent().getStringExtra("class");
        sub=getIntent().getStringExtra("subject");
        //getting firebase objects
        mStorageReference = FirebaseStorage.getInstance().getReference("Academic").child("Timetable").child(class_sec);
        mDatabaseReference = FirebaseDatabase.getInstance().getReference("Staff_Details").child("Academic").child("Timetable").child(class_sec);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openurl();
            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadsheet();
              //  progressBar.setVisibility(View.GONE);
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                downloadfile();
            }
        });

    }

    public void openurl(){
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://docs.google.com/spreadsheets/")));
    }

    public void uploadsheet(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        Intent intent = new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Timetable Pdf"), 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //when the user choses the file
        if (requestCode == 100 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            //if a file is selected
            if (data.getData() != null) {
                //uploading the file
                uploadFile(data.getData());
            }else{
                Toast.makeText(this, "No file chosen", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void uploadFile(Uri data) {
            if(!data.toString().equals("")) {
                progressBar.setVisibility(View.VISIBLE);
                final StorageReference sRef = mStorageReference.child("timetable.pdf");
                mUploadTask = sRef.putFile(data)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @SuppressWarnings("VisibleForTests")
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                progressBar.setVisibility(View.GONE);

                                final String[] getting_url = new String[1];

                                sRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        geturl[0] = uri.toString();
                                        getting_url[0] = uri.toString();
                                        Upload upload = new Upload("timetable", getting_url[0]);
                                        mDatabaseReference.setValue(upload);
                                        Toast.makeText(getApplicationContext(), "sucess upload", Toast.LENGTH_SHORT).show();
                                    }
                                });
                                //finish

                                // progressBar.setVisibility(View.GONE);
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                Toast.makeText(getApplicationContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @SuppressWarnings("VisibleForTests")
                            @Override
                            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                                double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                progressBar.setProgress((int) progress);
                                //   textViewStatus.setText((int) progress + "% Uploading...");
                            }
                        });
            }else Toast.makeText(getApplicationContext(),"select pdf",Toast.LENGTH_SHORT).show();
    }

    public void downloadfile(){
        DownloadManager dm=(DownloadManager)getApplicationContext().getSystemService(getApplicationContext().DOWNLOAD_SERVICE);
        Uri urll=Uri.parse(geturl[0]);
        DownloadManager.Request request= new DownloadManager.Request(urll);

        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        request.setDestinationInExternalFilesDir(getApplicationContext(),DIRECTORY_DOWNLOADS,"timetable.pdf");

        dm.enqueue(request);
    }
}