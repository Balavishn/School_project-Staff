package com.example.staff_navigations.ui.signout;

import androidx.lifecycle.ViewModel;

public class SignoutViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}