package com.example.staff_navigations.ui.homepage;

import androidx.lifecycle.ViewModel;

public class HomepageViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}