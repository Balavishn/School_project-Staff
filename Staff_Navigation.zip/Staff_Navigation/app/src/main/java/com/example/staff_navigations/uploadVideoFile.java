package com.example.staff_navigations;
public class uploadVideoFile{
    public String name;
    public String url;

    public uploadVideoFile() {
    }

    public uploadVideoFile(String name, String url) {
        this.name = name;
        this.url = url;
    }

    public String getName() {
        return name;
    }


    public String getUrl() {
        return url;
    }

}

