package com.example.staff_navigations.ui.leave;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.staff_navigation.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LeaveFragment extends Fragment {

    private LeaveViewModel mViewModel;
    EditText name,id,leave,days;
    Button submit;
    DatabaseReference ref;
    public static LeaveFragment newInstance() {
        return new LeaveFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_leave, container, false);
        name=view.findViewById(R.id.leave_name);
        id=view.findViewById(R.id.leave_teacher_id);
        leave=view.findViewById(R.id.leave_nature);
        days=view.findViewById(R.id.leave_days);
        submit=view.findViewById(R.id.submit_leave);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!name.getText().toString().equals("") && !id.getText().toString().equals("") && !leave.getText().toString().equals("")
                        && !days.getText().toString().equals("")
                ) {
                    ref = FirebaseDatabase.getInstance().getReference("leave");
                    LeaveData data = new LeaveData(name.getText().toString(), id.getText().toString(), leave.getText().toString(), days.getText().toString());
                    ref.push().setValue(data).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(getContext(), "success", Toast.LENGTH_SHORT).show();
                        }
                    });
                }else Toast.makeText(view.getContext(),"Enter All Field name",Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(LeaveViewModel.class);
        // TODO: Use the ViewModel

    }

}