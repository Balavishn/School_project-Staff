package com.example.staff_navigations;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.staff_navigation.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class academic_syllabus extends AppCompatActivity {
    TextView count;
    EditText title,desc;
    ProgressBar bar;
    ImageView sy_img;
    StorageReference mStorageRef;
    DatabaseReference reference;
    Intent i;
    String class_sec,sub;
    Uri uri;
    Button up;
    StorageTask mUploadTask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_academic_syllabus);
        count=findViewById(R.id.upload_per);
        bar=findViewById(R.id.progresss);
        sy_img=findViewById(R.id.upload_image);
        up=findViewById(R.id.upload_button);
        bar.setVisibility(View.GONE);
        title=findViewById(R.id.syll_title);
        desc=findViewById(R.id.syll_desc);
        SharedPreferences preferences =getSharedPreferences("NUMBER",MODE_PRIVATE);
        String s=preferences.getString("Register","default");
        reference= FirebaseDatabase.getInstance().getReference("Staff_Details").child(s).child("Academic").child("syllabus");
        mStorageRef = FirebaseStorage.getInstance().getReference("Academic").child("syllabus");
        class_sec=getIntent().getStringExtra("class");
        sub=getIntent().getStringExtra("subject");
        sy_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(i,100);
            }
        });

        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mUploadTask != null && mUploadTask.isInProgress()) {
                    Toast.makeText(getApplicationContext(), "Upload in progress", Toast.LENGTH_LONG).show();
                } else {

                    upload();}
                }

        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        bar.setVisibility(View.VISIBLE);
        uri=data.getData();
        Log.d("syllabusfile",uri.toString());
        sy_img.setImageURI(uri);
    }

    public void upload(){
        if(!title.getText().toString().equals("") && !desc.getText().toString().equals("")) {
                final Map<String, String> data = new HashMap<>();
                data.put("title", title.getText().toString());
                data.put("description", desc.getText().toString());
            mUploadTask=  mStorageRef.child(class_sec).child(sub).child(title.getText().toString() + ".jpg").putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Toast.makeText(getApplicationContext(), "sucess", Toast.LENGTH_SHORT).show();
                        mStorageRef.child(class_sec).child(sub).child(title.getText().toString() + ".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri urii) {
                                data.put("image",urii.toString());
                                reference.child(class_sec).child(sub).setValue(data);
                                Toast.makeText(getApplicationContext(), "sucess2", Toast.LENGTH_SHORT).show();
                            }
                        }
                        )
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                    }
                })
                        .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                                double p = (100 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                                bar.setProgress((int) p);
                                count.setText(p + "%");
                            }
                        })

                ;

        }
        else{
            Toast.makeText(getApplicationContext(),"enter Fields",Toast.LENGTH_SHORT).show();
        }
    }
}